<h1>Hello <?php echo e($name); ?></h1>




<?php /**PATH D:\Floders\projects\Api2\apiCare\resources\views/mail.blade.php ENDPATH**/ ?>